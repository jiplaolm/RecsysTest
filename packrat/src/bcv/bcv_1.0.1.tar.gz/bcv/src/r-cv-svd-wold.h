
#ifndef _R_CV_SVD_WOLD_H
#define _R_CV_SVD_WOLD_H
 
SEXP R_cv_svd_wold (SEXP x, SEXP k, SEXP maxrank, SEXP tol, SEXP maxiter, 
                    SEXP sets);

#endif /* _R_CV_SVD_WOLD_H */
