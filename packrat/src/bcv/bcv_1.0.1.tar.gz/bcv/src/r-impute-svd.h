
#ifndef _R_IMPUTE_SVD_H
#define _R_IMPUTE_SVD_H
 
SEXP R_impute_svd (SEXP x, SEXP k, SEXP tol, SEXP maxiter);

#endif /* _R_IMPUTE_SVD_H */
