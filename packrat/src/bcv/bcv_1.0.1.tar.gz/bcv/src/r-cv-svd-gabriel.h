
#ifndef _R_CV_SVD_GABRIEL_H
#define _R_CV_SVD_GABRIEL_H
 
SEXP R_cv_svd_gabriel (SEXP xx, SEXP KK, SEXP LL, SEXP max_rank, 
                        SEXP s_r, SEXP s_c);

#endif /* _R_CV_SVD_GABRIEL_H */
